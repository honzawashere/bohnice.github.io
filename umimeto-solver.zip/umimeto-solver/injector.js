(function () {
    // just to make sure it'll never get really detectable, we'll create a random letter id for the script element
    function generateRandomString() {
        var letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        var result = '';
        for (var i = 0; i < 8; i++) {
            result += letters.charAt(Math.floor(Math.random() * letters.length));
        }
        return result;
    }

    let randomId = generateRandomString()

    let scriptElement = document.createElement("script")

    scriptElement.id = randomId
    scriptElement.type = "module"
    scriptElement.src = "http://127.0.0.1:5500/script/base.js"
    document.body.appendChild(scriptElement)

    scriptElement.addEventListener("load", () => {
        // removing the script before the page will detect it
        document.querySelector("#" + randomId).remove()
    })
})()