export default function clear() {
    console.clear()
}