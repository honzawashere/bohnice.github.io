import getExerciseData from "./getExerciseData.js"
import isInExercise from "./isInExercise.js"
import clear from "./utils.js"

let style = "color: #FF76FF"
let prefix = "background: #FF76FF; border-radius: 8px; color: white; font-weight: bold;"

let uiStyle = "color: #FF76B2"
let uiPrefix = "background: #FF76B2; border-radius: 8px; color: white; font-weight: bold;"

export default function injectUI() {
    console.log(`%c umimeto.bohnice.wtf > injectUI %c Injecting...`, prefix, style)

    const uiElement = document.createElement("div")
    uiElement.id = "cheatUI"
    uiElement.classList.add("cheatUI")
    uiElement.innerHTML = [
        `<link rel="stylesheet" href="http://127.0.0.1:5500/script/ui/interface.css">`,
        `<script src="http://127.0.0.1:5500/script/ui/interface.js"></script>`,
        ``,
        `<link rel="preconnect" href="https://fonts.googleapis.com">`,
        `<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>`,
        `<link`,
        `href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"`,
        `rel="stylesheet">`,
        `<div class="userInterface">`,
        `<div class="userInterfaceLogo">`,
        `<svg xmlns="http://www.w3.org/2000/svg" xmlns:v="https://vecta.io/nano" width="50px" height="50px"`,
        `viewBox="0 0 50.8 50.8">`,
        `<circle r="11.487453" cy="16.31219483765" cx="25.27951801733" fill="#f1c40f" paint-order="normal" />`,
        `<path`,
        `d="M21.403141 42.845412l5.993454 2.99673m-6.99236-10.71057l7.991275 3.99563m-8.514716-12.66484c-4.838492-2.93274-6.395354-6.96327-5.876369-11.245835.570501-4.707224 4.786259-10.303115 11.417521-10.258412 6.041618.041671 11.50384 5.207364 11.45815 11.552515-.06135 8.484592-9.017975 9.588442-9.017975 15.960142"`,
        `fill="none" stroke="#2c3e50" stroke-width="3.99563" stroke-linecap="round"`,
        `stroke-linejoin="round" />`,
        `</svg>`,
        `<div class="userInterfaceLogoTexts">`,
        `<h1>NeumimeTo</h1>`,
        `<h2>Nejlepší cheat na umimeto.org</h2>`,
        `</div>`,
        `</div>`,
        `<br>`,
        `<div class="userInterfaceSettings">`,
        `<div class="userInterfaceSetting">`,
        `<svg xmlns="http://www.w3.org/2000/svg" version="1.0" width="25px" height="25px"`,
        `viewBox="0 0 512.000000 512.000000" preserveAspectRatio="xMidYMid meet">`,
        ``,
        `<g transform="translate(0.000000,512.000000) scale(0.100000,-0.100000)" fill="#ffffffd0"`,
        `stroke="none">`,
        `<path`,
        `d="M2220 5044 c-41 -35 -106 -171 -211 -445 l-84 -217 -117 -47 -116 -48 -199 80 c-346 141 -464 179 -516 167 -22 -5 -88 -63 -239 -212 -115 -113 -211 -216 -214 -229 -12 -45 43 -192 190 -512 42 -90 76 -170 76 -177 0 -18 -81 -207 -94 -220 -6 -6 -110 -50 -231 -99 -269 -107 -391 -164 -433 -203 l-32 -30 0 -300 c0 -288 1 -300 21 -326 29 -37 151 -93 434 -199 l247 -93 48 -113 48 -113 -90 -206 c-102 -237 -168 -423 -168 -473 0 -32 17 -52 212 -246 151 -149 221 -212 241 -215 54 -10 225 51 552 196 l150 67 117 -47 117 -47 81 -196 c117 -281 193 -433 230 -464 l32 -27 298 0 298 0 32 26 c41 35 109 177 210 439 45 116 86 215 93 221 7 6 60 30 118 54 l106 42 241 -96 c405 -163 450 -174 510 -133 20 15 124 114 231 221 l193 195 -7 48 c-9 62 -56 180 -171 432 -52 113 -94 210 -94 216 0 18 81 209 94 221 6 6 110 50 231 99 260 103 394 167 435 205 l30 28 0 302 0 303 -34 32 c-41 39 -139 82 -440 194 l-229 86 -47 114 -47 113 89 207 c101 235 168 422 168 472 0 31 -17 51 -204 237 -118 116 -219 208 -239 217 -29 12 -41 12 -90 -1 -68 -18 -267 -97 -471 -188 l-150 -66 -117 46 -118 47 -47 111 c-174 418 -219 512 -266 551 l-30 25 -298 0 -298 0 -32 -26z m583 -1658 c154 -46 278 -119 385 -227 333 -336 334 -862 1 -1198 -105 -105 -262 -197 -404 -236 -82 -22 -272 -30 -364 -16 -183 29 -353 116 -485 248 -418 418 -304 1104 229 1370 139 70 253 94 420 89 104 -3 148 -9 218 -30z">`,
        `</path>`,
        `</g>`,
        `</svg>`,
        `<h1 id="cheatStatus">Stav: N/A</h1>`,
        `</div>`,
        `<div class="userInterfaceSetting">`,
        `<svg xmlns="http://www.w3.org/2000/svg" version="1.0" width="25px" height="25px"`,
        `viewBox="0 0 512.000000 512.000000" preserveAspectRatio="xMidYMid meet">`,
        ``,
        `<g transform="translate(0.000000,512.000000) scale(0.100000,-0.100000)" fill="#ffffffd0"`,
        `stroke="none">`,
        `<path`,
        `d="M2105 5108 c-52 -19 -82 -47 -109 -100 -33 -67 -33 -112 2 -179 22 -43 38 -59 81 -81 49 -26 62 -28 167 -28 l114 0 0 -199 0 -199 -27 -6 c-16 -2 -50 -8 -78 -11 -196 -25 -433 -99 -640 -200 -232 -114 -387 -223 -569 -403 -397 -391 -620 -896 -643 -1457 -24 -601 204 -1183 632 -1610 543 -542 1321 -755 2069 -566 511 130 967 455 1264 901 170 255 291 573 338 890 24 156 24 454 0 608 -57 372 -195 706 -414 997 l-61 80 109 110 c111 113 133 145 145 206 21 111 -86 230 -205 229 -54 -1 -116 -42 -225 -150 l-110 -110 -45 37 c-138 111 -374 245 -556 316 -143 56 -351 107 -536 132 l-48 6 0 200 0 199 115 0 c127 0 169 11 218 58 43 41 60 81 60 142 0 61 -17 101 -60 142 -60 58 -64 58 -530 57 -275 0 -439 -4 -458 -11z m626 -1189 c685 -69 1260 -517 1493 -1159 216 -598 89 -1265 -333 -1757 -186 -216 -478 -413 -751 -506 -181 -61 -318 -86 -515 -94 -593 -22 -1147 252 -1503 745 -75 105 -190 332 -232 459 -306 928 200 1930 1127 2232 242 79 474 105 714 80z" />`,
        `<path`,
        `d="M3265 3126 c-39 -19 -139 -113 -456 -432 -224 -225 -415 -425 -424 -444 -35 -68 -14 -182 41 -231 60 -52 159 -67 224 -34 46 22 846 819 870 865 45 87 33 169 -34 236 -66 66 -138 79 -221 40z" />`,
        `</g>`,
        `</svg>`,
        `<h1>Delay: 500</h1>`,
        `</div>`,
        `<div class="userInterfaceSetting">`,
        `<svg xmlns="http://www.w3.org/2000/svg" version="1.0" width="25px" height="25px"`,
        `viewBox="0 0 512.000000 512.000000" preserveAspectRatio="xMidYMid meet">`,
        ``,
        `<g transform="translate(0.000000,512.000000) scale(0.100000,-0.100000)" fill="#ffffffd0"`,
        `stroke="none">`,
        `<path`,
        `d="M2423 4770 c-268 -34 -510 -154 -697 -347 -96 -99 -149 -174 -211 -298 -291 -586 -41 -1295 557 -1575 179 -83 406 -122 596 -102 417 46 753 278 937 647 340 683 -64 1505 -816 1659 -97 20 -273 27 -366 16z m322 -249 c365 -75 651 -363 727 -731 26 -122 20 -307 -12 -419 -91 -320 -328 -561 -645 -657 -83 -25 -104 -28 -255 -28 -151 0 -172 3 -255 28 -314 95 -549 332 -641 643 -37 126 -44 302 -16 433 105 507 597 834 1097 731z" />`,
        `<path`,
        `d="M2376 2199 c-533 -41 -1033 -266 -1394 -627 -260 -260 -437 -598 -497 -946 -22 -128 -20 -207 6 -239 30 -39 85 -53 131 -34 51 21 69 55 79 144 28 249 107 464 248 675 282 422 775 710 1351 789 127 17 414 15 554 -5 601 -85 1118 -419 1384 -894 100 -179 155 -348 182 -564 14 -112 44 -148 126 -148 28 0 44 8 71 35 l36 36 -6 97 c-32 489 -348 995 -817 1307 -336 224 -690 343 -1110 375 -150 11 -186 11 -344 -1z" />`,
        `</g>`,
        `</svg>`,
        `<h1 id="cheatUserId">ID Uživatele: null</h1>`,
        `</div>`,
        `</div>`,
        `<div class="spoofResponseCheat">`,
        `<input type="checkbox" id="spoofResponses">`,
        `<h1 class="spoofResponseText" id="spoofResponses">Zblbnout kontrolu odpovědí</h1>`,
        `</div>`,
        `<div class="userInterfaceButtons">`,
        `<button id="destroyButton">Killnout Cheat</button>`,
        `<button id="cheatToggleButton" class="disabled">Soon</button>`,
        `</div>`,
        `</div>`
    ].join(" ")

    document.body.appendChild(uiElement)
    console.log(`%c umimeto.bohnice.wtf > UI %c Injected!`, uiPrefix, uiStyle)

    let trollge = "color: red;"
    let trollgePrefix = "background: red; border-radius: 8px; color: white; font-weight: bold;"

    setTimeout(() => {
        console.log([
            `%c The "umimeto.org má špatně zabezpečený kód" incident... %c`,
            `⠀⠀⠉⠛⠛⠻⢿⣿⣿⣿⣿⣿⣿⣶⣶⣶⣶⣶⣶⣶⣶⣦⣤⣄⡀⠀⠀⠀⠀⠀ `,
            ` ⠀⠀⠀⠀⠀⠀⠚⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡄⠀⠀ `,
            `⠀⠀⠀⠀⠀⠀⠀⠘⠛⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⠀⠀ `,
            `⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⢿⣿⣿⣿⠟⠛⠋⠉⠉⠉⠙⣿⣿⣿⣿⣶⣀⠀ `,
            `⠀⠀⠀⠰⠶⠿⢰⣿⣶⣦⠀⠀⢸⣿⣿⣦⡄⠀⢀⣴⣾⣿⣿⣿⡿⠿⣿⣿⣿⠇`,
            `⠀⠀⠀⠀⠀⠀⠀⠻⠿⠃⠀⠀⠀⣿⣿⣿⣧⠀⠀⠉⣉⣉⣩⣥⡶⠀⠀⠀⣿⡇ `,
            `⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⣿⣿⣿⣿⠀⠀⣻⣿⣿⣿⠃⠀⠀⢠⣿⠃ `,
            `⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠉⠁⣴⣿⣿⣿⠟⠃⡀⠀⢠⣿⠟⠀ `,
            `⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣤⣄⠀⣤⣤⣤⢰⣿⡦⣿⠀⣿⣿⠀⠀ `,
            `⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠛⠛⠛⠀⠛⠛⠋⠈⠉⠀⠀⢀⣿⣿⠀⠀ `,
            `⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢴⡆⣤⣤⣄⡄⢀⣀⣀⢀⣀⢀⡄⠀⢨⣿⣿⠀⠀`,
            `⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠃⣿⣿⣿⠇⣿⣿⡋⣿⠏⠛⣃⣤⣾⣿⣿⠀⠀`,
            `⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⣤⣄⣠⣤⣠⣴⣶⣾⣿⣿⣿⣿⣿⣿⡀⠀`,
            `⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀`,
            `⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠺⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠁ `,
        ].join("\n"), trollgePrefix, trollge)
    }, 1000)

    document.querySelector("#cheatUserId").innerHTML = "ID uživatele: " + window.user
    if (isInExercise()) {
        document.querySelector("#cheatStatus").innerHTML = "Stav: Ve cvičení"
        //document.querySelector("#cheatToggleButton").classList.remove("disabled")
    } else {
        document.querySelector("#cheatStatus").innerHTML = "Stav: Mimo cvičení"
        //document.querySelector("#cheatToggleButton").classList.add("disabled")
    }

    document.querySelector("#spoofResponses").onclick = () => {
        if (document.querySelector("#spoofResponses").checked) {
            window.classifyAnswer = (correct, responseTime) => {
                return "correct"
            }
        } else {
            window.classifyAnswer = (correct, responseTime) => {
                if (correct) {
                    return "correct"
                } else {
                    if (inRow >= 6) {
                        return "nearMiss"
                    }
                    if (responseTime >= guessThresholdTime) {
                        return "wrongNormal";
                    } else {
                        return "wrongGuess";
                    }
                }
            }
        }
    }

    document.querySelector("#destroyButton").onclick = () => {
        document.querySelector("#cheatUI").remove()
        document.body.removeAttribute("neumimeto")
        clear()
    }

    document.querySelector("#cheatToggleButton").onclick = () => {
        //getExerciseData()
    }
}