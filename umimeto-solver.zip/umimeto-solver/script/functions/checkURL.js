let validURLs = [
    "umimeto.cz",
    "umimecesky.cz",
    "umimematiku.cz",
    "umimeanglicky.cz",
    "umimeinformatiku.cz",
    "umimefakta.cz",
    "umimenemecky.cz",
    "umimeto.org"
]

let style = "color: #FF76FF"
let prefix = "background: #FF76FF; border-radius: 8px; color: white; font-weight: bold;"

let isValidURL = false;

export default function checkURL() {
    console.log(`%c umimeto.bohnice.wtf > checkURL %c ${document.URL}`, prefix, style)
    for (let i = 0; i < validURLs.length; i++) {
        if (document.URL.includes(validURLs[i])) {
            isValidURL = true;
            break;
        }
    }

    return isValidURL
}