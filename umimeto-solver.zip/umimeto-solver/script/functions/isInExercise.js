let validURLs = [
    "/doplnovacka",
    "/rozhodovacka",
    "?p=zavodyPsani",
    "?p=zavody",
    "?p=tymovka",
    "/vpisovacka",
    "/hadanky",
    "/diktat",
    "/ukolovka",
    "/pexeso",
    "/otazky",
    "/rozrazovacka",
    "/roboti",
    "/mluvene-diktaty",
    "/krok-po-kroku",
    "/chat",
    "/odvozovani",
    "/rozbory",
    "/tvorba_slov",
    "/presouvani",
    "/psani-carek",
    "/carky",
    "/carek",
]

let style = "color: #FF76FF"
let prefix = "background: #FF76FF; border-radius: 8px; color: white; font-weight: bold;"

let isExercise = false;

export default function isInExercise() {
    for (let i = 0; i < validURLs.length; i++) {
        if (document.URL.includes(validURLs[i])) {
            isExercise = true;
            break;
        }
    }

    console.log(`%c umimeto.bohnice.wtf > isInExercise %c ${isExercise}`, prefix, style)
    return isExercise
}