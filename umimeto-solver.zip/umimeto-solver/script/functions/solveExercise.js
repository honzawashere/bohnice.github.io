let style = "color: #BFFF76"
let prefix = "background: #BFFF76; border-radius: 8px; color: white; font-weight: bold;"

function getExerciseType() {
    console.log(`%c umimeto.bohnice.wtf > solveExercise > getExerciseType %c Type: ${document.URL.split("/")[3].split("-")[0]}`, prefix, style)
    return document.URL.split("/")[3].split("-")[0]
}


export default function solveExercise(delayBetweenTasks, exerciseData) {
    const exerciseType = getExerciseType()

    if (exerciseType.includes("doplnovacka") || exerciseType.includes("rozhodovacka")) {
        let progress = 0

        if (document.querySelector("#cheatUI").getAttribute("progress") !== null) {
            progress = document.querySelector("#cheatUI").getAttribute("progress")
        }

        function clickAnswers() {
            // borrowed from https://github.com/MP3Martin/umimeto-solver/blob/main/source/main.js, edited by honzawashere
            const answers = exerciseData.items;
            console.log(answers)
            let length = answer.options.length
            if(document.querySelector("#question-content > div.image")) {
                for (let i = 0; i < length; i++) {
                    if (answer.options[i].correct === 1) {
                        document.querySelector("#option" + Math.floor(i)).click()
                        progress++
                        length = 0
                        setTimeout(() => {
                            clickAnswers()
                        }, delayBetweenTasks + 1000)
                    }
                }
            }
        }

        clickAnswers()
    } else if (exerciseType.includes("?p=zavodyPsani")) {

    } else if (exerciseType.includes('?p=zavody') || exerciseType.includes('?p=tymovka')) {

    } else if (exerciseType.includes("/vpisovacka")) {

    } else if (exerciseType.includes("/hadanky")) {

    } else if (exerciseType.includes("/diktat")) {

    } else if (exerciseType.includes("/ukolovka")) {

    } else if (exerciseType.includes("/pexeso")) {

    } else if (exerciseType.includes("/otazky")) {

    } else if (exerciseType.includes("/rozrazovacka")) {

    } else if (exerciseType.includes("/roboti")) {

    } else if (exerciseType.includes("/mluvene-diktaty")) {

    } else if (exerciseType.includes('/krok-po-kroku') || exerciseType.includes('/chat') || exerciseType.includes('/odvozovani')) {

    } else if (exerciseType.includes("/rozbory") || exerciseType.includes("/tvorba_slov")) {

    } else if (exerciseType.includes("/psani-carek") || exerciseType.includes("/carky") || exerciseType.includes("/carek")) {

    } else if (exerciseType.includes("/mluvene-diktaty")) {

    }
}