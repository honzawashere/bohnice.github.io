import solveExercise from "./solveExercise.js"

let style = "color: #FF76FF"
let prefix = "background: #FF76FF; border-radius: 8px; color: white; font-weight: bold;"

let styleSpecial = "color: #FF7676;"
let nextSpecial = "color: #FFDA76;"
let prefixSpecial = "background: #FF7676; border-radius: 8px; color: white; font-weight: bold;"
let prefixNextSpecial = "background: #FFDA76; border-radius: 8px; color: white; font-weight: bold;"
let justWhite = "color: white";

function base64DecodeUnicode(encodedString) {
    const decodedString = atob(encodedString);
    let decodedUnicode = '';

    for (let i = 0; i < decodedString.length; i++) {
        decodedUnicode += '%' + decodedString.charCodeAt(i).toString(0x10).padStart(0x2, '0');
    }
    
    console.log(`%c umimeto.bohnice.wtf > getExerciseData > base64DecodeUnicode %c Decoding response... %c${encodedString.substring(0, 20)}...`, prefixSpecial, styleSpecial, justWhite)
    console.log(`%c umimeto.bohnice.wtf > getExerciseData > base64DecodeUnicode %c Response is: %c${decodedString.substring(0, 20)}...`, prefixSpecial, styleSpecial, justWhite)
    console.log(`%c umimeto.bohnice.wtf > getExerciseData > base64DecodeUnicode %c Translating to Unicode... %c${decodedString.substring(0, 20)}...`, prefixSpecial, styleSpecial, justWhite)
    console.log(`%c umimeto.bohnice.wtf > getExerciseData > base64DecodeUnicode %c Final response is: %c${decodeURIComponent(decodedUnicode).substring(0, 20)}...`, prefixSpecial, styleSpecial, justWhite)
    return decodeURIComponent(decodedUnicode);
}

function decryptSimpleSubstitutionCipher(encryptedString) {
    const reversedAlphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
    const originalAlphabet = ['z', 'y', 'x', 'w', 'v', 'u', 't', 's', 'r', 'q', 'p', 'o', 'n', 'm', 'l', 'k', 'j', 'i', 'h', 'g', 'f', 'e', 'd', 'c', 'b', 'a'];

    console.log(`%c umimeto.bohnice.wtf > getExerciseData > decryptSimpleSubstitutionCipher %c Decrypting cipher... %c${encryptedString.substring(0, 20)}...`, prefixNextSpecial, nextSpecial, justWhite)
    console.log(`%c umimeto.bohnice.wtf > getExerciseData > decryptSimpleSubstitutionCipher %c Cipher is: %c${mapString(encryptedString, reversedAlphabet, originalAlphabet).substring(0, 20)}...`, prefixNextSpecial, nextSpecial, justWhite)
    return mapString(encryptedString, reversedAlphabet, originalAlphabet);
}

export default function getExerciseData() {
    const apiUrl = "https://" + document.URL.split("/")[2] + "/ajax/"

    // checking which endpoint we should use, but in most cases it's the doplnovackaLoadQuestionsBinaryChoiceData.php
    const type = window.psType === ('resourceData' && window.specs.resourceData === 'binaryChoice') ? 'universalLoadMedal.ps' : 'doplnovackaLoadQuestionsBinaryChoiceData.php';
    
    const data = new URLSearchParams({ user: window.user, ps: window.ps, kc: window.kc, chosenProblem: window.chosenProblem, exercise: window.exercise, cookieHash: window.cookieHash })

    console.log(`%c umimeto.bohnice.wtf > getExerciseData %c Fetching from ${apiUrl}${type}?${data.toString()}`, prefix, style)
    fetch(`${apiUrl}${type}?${data.toString()}`).then(async (response) => {
        const Response = await response.text()

        // congratulations, umimeto, you've tried to encrypt exercise.
        // however, we're not dumb and we're not on fucking piskoviste here,
        // so your reversed alphabet and base64 thing isn't doing shit.
        if(!Response.trim().startsWith("{")) {
            const exercise = JSON.parse(base64DecodeUnicode(decryptSimpleSubstitutionCipher(Response)))
            console.log(`%c umimeto.bohnice.wtf > getExerciseData %c Successfully fetched response data`, prefix, style)
            solveExercise(500, exercise)
            console.log(exercise)
        }
    })
}