import checkURL from "./functions/checkURL.js"
import injectUI from "./functions/injectUI.js"

let style = "color: #C776FF"
let prefix = "background: #C776FF; border-radius: 8px; color: white; font-weight: bold;"

// this to prevent user from running multiple sessions of this cheat at once...
if (document.body.getAttribute("neumimeto") === true) {
    console.log(`%c umimeto.bohnice.wtf %c Script was already loaded, quitting...`, prefix, style)
} else {
    document.body.setAttribute("neumimeto", true)

    console.log(`%c umimeto.bohnice.wtf %c Hello world!`, prefix, style)

    if (checkURL()) {
        console.log(`%c umimeto.bohnice.wtf %c Loading...`, prefix, style)
        injectUI()
    } else {
        console.log(`%c umimeto.bohnice.wtf %c This site is not supported.`, prefix, style)
    }
}